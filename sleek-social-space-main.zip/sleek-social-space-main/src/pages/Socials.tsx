
import React from "react";
import Layout from "@/components/Layout";
import { socials } from "@/data/socials";
import { Card, CardContent } from "@/components/ui/card";
import { ExternalLink } from "lucide-react";

const Socials: React.FC = () => {
  return (
    <Layout>
      <div className="page-container">
        <h1 className="text-3xl font-bold mb-2">Connect With Me</h1>
        <p className="text-gray-600 mb-8">
          Find me on various platforms and social media
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {socials.map((social) => {
            const IconComponent = social.icon;
            
            return (
              <Card key={social.name} className="overflow-hidden transform transition-all hover:scale-105">
                <CardContent className="p-0">
                  <a
                    href={social.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center p-6 hover:bg-gray-50 transition"
                    style={{ color: social.color }}
                  >
                    <div className="mr-4 p-3 rounded-full" style={{ backgroundColor: `${social.color}20` }}>
                      <IconComponent size={24} strokeWidth={2} />
                    </div>
                    <div className="flex-grow">
                      <h3 className="font-bold text-xl">{social.name}</h3>
                      <p className="text-gray-600">{social.username}</p>
                    </div>
                    <ExternalLink className="text-gray-400" size={20} />
                  </a>
                </CardContent>
              </Card>
            );
          })}
        </div>

        <div className="mt-12 text-center">
          <p className="text-gray-600">
            Looking forward to connecting with you on any of these platforms!
          </p>
        </div>
      </div>
    </Layout>
  );
};

export default Socials;
