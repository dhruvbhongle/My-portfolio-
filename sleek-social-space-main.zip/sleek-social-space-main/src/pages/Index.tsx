
import React from "react";
import Layout from "@/components/Layout";
import ProfileSection from "@/components/ProfileSection";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";

const Index: React.FC = () => {
  const skills = [
    "JavaScript (ES6+)", 
    "TypeScript", 
    "React", 
    "Next.js", 
    "HTML5", 
    "CSS3/SCSS", 
    "Tailwind CSS",
    "Node.js",
    "Git",
    "Responsive Design"
  ];

  const experiences = [
    {
      role: "Senior Frontend Developer",
      company: "Tech Solutions Inc.",
      period: "2020 - Present",
      description: "Leading frontend development team, implementing modern UI libraries, and optimizing application performance."
    },
    {
      role: "Frontend Developer",
      company: "Digital Innovations",
      period: "2018 - 2020",
      description: "Developed responsive web applications and collaborated with designers to implement UI/UX improvements."
    },
    {
      role: "Web Developer Intern",
      company: "StartUp Hub",
      period: "2017 - 2018",
      description: "Assisted in developing web applications and gained hands-on experience with modern frontend frameworks."
    }
  ];

  return (
    <Layout>
      <div className="page-container">
        <section className="mb-16">
          <ProfileSection />
        </section>

        <Separator className="my-10" />

        <section className="mb-16">
          <h2 className="section-title">About Me</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-8">
            <div>
              <h3 className="text-xl font-semibold mb-4">Who I Am</h3>
              <p className="text-gray-600">
                I'm a passionate frontend developer with a keen eye for design and a commitment to creating seamless user experiences. With over 5 years of experience in web development, I've worked on projects ranging from small business websites to complex enterprise applications.
              </p>
              <p className="text-gray-600 mt-4">
                My approach combines technical expertise with creative problem-solving, allowing me to build applications that are not only functional but also intuitive and visually appealing. I'm constantly learning and evolving my skills to stay at the forefront of web development trends.
              </p>
            </div>
            <div>
              <h3 className="text-xl font-semibold mb-4">Skills & Expertise</h3>
              <div className="flex flex-wrap gap-2">
                {skills.map((skill, index) => (
                  <span
                    key={index}
                    className="bg-portfolio-lightBlue text-portfolio-blue px-3 py-1 rounded-full text-sm"
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </section>

        <section className="mb-16">
          <h2 className="section-title">Experience</h2>
          <div className="space-y-6 mt-8">
            {experiences.map((exp, index) => (
              <Card key={index}>
                <CardContent className="p-6">
                  <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-2">
                    <h3 className="text-xl font-bold">{exp.role}</h3>
                    <span className="text-portfolio-blue">{exp.period}</span>
                  </div>
                  <h4 className="text-portfolio-gray mb-3">{exp.company}</h4>
                  <p className="text-gray-600">{exp.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>
      </div>
    </Layout>
  );
};

export default Index;
