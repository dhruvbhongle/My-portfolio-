
import React, { useState, useEffect, useMemo } from "react";
import Layout from "@/components/Layout";
import ProjectCard from "@/components/ProjectCard";
import SearchBar from "@/components/SearchBar";
import Pagination from "@/components/Pagination";
import { projects } from "@/data/projects";

const Projects: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const projectsPerPage = 6;

  // Reset to first page when search query changes
  useEffect(() => {
    setCurrentPage(1);
  }, [searchQuery]);

  // Filter projects based on search query
  const filteredProjects = useMemo(() => {
    return projects.filter((project) =>
      project.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      project.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      project.category.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [searchQuery, projects]);

  // Calculate pagination
  const indexOfLastProject = currentPage * projectsPerPage;
  const indexOfFirstProject = indexOfLastProject - projectsPerPage;
  const currentProjects = filteredProjects.slice(indexOfFirstProject, indexOfLastProject);
  const totalPages = Math.ceil(filteredProjects.length / projectsPerPage);

  return (
    <Layout>
      <div className="page-container">
        <h1 className="text-3xl font-bold mb-2">My Projects</h1>
        <p className="text-gray-600 mb-8">
          Explore my latest work and ongoing projects
        </p>

        <div className="mb-8 max-w-md">
          <SearchBar query={searchQuery} setQuery={setSearchQuery} />
        </div>

        {filteredProjects.length === 0 ? (
          <div className="text-center py-16">
            <h3 className="text-xl font-medium mb-2">No projects found</h3>
            <p className="text-gray-500">
              Try adjusting your search criteria
            </p>
          </div>
        ) : (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {currentProjects.map((project) => (
                <ProjectCard key={project.id} project={project} />
              ))}
            </div>

            <Pagination
              currentPage={currentPage}
              totalPages={totalPages}
              onPageChange={setCurrentPage}
            />
          </>
        )}
      </div>
    </Layout>
  );
};

export default Projects;
