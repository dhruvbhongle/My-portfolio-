
import { Github, Instagram, Mail, MessageCircle } from "lucide-react";

export interface Social {
  name: string;
  url: string;
  icon: any;
  username: string;
  color: string;
}

export const socials: Social[] = [
  {
    name: "GitHub",
    url: "https://github.com/yourusername",
    icon: Github,
    username: "yourusername",
    color: "#333"
  },
  {
    name: "Instagram",
    url: "https://instagram.com/yourusername",
    icon: Instagram,
    username: "@yourusername",
    color: "#E1306C"
  },
  {
    name: "Discord",
    url: "https://discord.com/users/yourusername",
    icon: MessageCircle,
    username: "yourusername#0000",
    color: "#5865F2"
  },
  {
    name: "Email",
    url: "mailto:your.email@example.com",
    icon: Mail,
    username: "your.email@example.com",
    color: "#D44638"
  }
];
