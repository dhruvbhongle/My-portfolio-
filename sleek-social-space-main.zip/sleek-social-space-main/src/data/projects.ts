
export interface Project {
  id: number;
  title: string;
  description: string;
  image: string;
  category: string;
  link?: string;
}

export const projects: Project[] = [
  {
    id: 1,
    title: "E-commerce Website",
    description: "A full-featured e-commerce platform built with React and Node.js. Includes user authentication, product listings, cart functionality, and checkout process.",
    image: "https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d?auto=format&fit=crop&w=600",
    category: "Web Development",
    link: "https://github.com"
  },
  {
    id: 2,
    title: "Weather Application",
    description: "A weather application that provides real-time weather data and forecasts using OpenWeatherMap API. Features include location detection, 5-day forecast, and weather alerts.",
    image: "https://images.unsplash.com/photo-1461749280684-dccba630e2f6?auto=format&fit=crop&w=600",
    category: "API Integration",
    link: "https://github.com"
  },
  {
    id: 3,
    title: "Task Management System",
    description: "A collaborative task management system with real-time updates, designed for team productivity. Features include task assignment, deadlines, and progress tracking.",
    image: "https://images.unsplash.com/photo-1488590528505-98d2b5aba04b?auto=format&fit=crop&w=600",
    category: "Web Development",
    link: "https://github.com"
  },
  {
    id: 4,
    title: "Fitness Tracking App",
    description: "A mobile fitness tracking application built with React Native. Tracks workouts, calories, and progress over time with visual data representation.",
    image: "https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=600",
    category: "Mobile Development",
    link: "https://github.com"
  },
  {
    id: 5,
    title: "Social Media Dashboard",
    description: "A comprehensive dashboard for social media analytics, providing insights into engagement metrics across multiple platforms.",
    image: "https://images.unsplash.com/photo-1649972904349-6e44c42644a7?auto=format&fit=crop&w=600",
    category: "Data Visualization",
    link: "https://github.com"
  },
  {
    id: 6,
    title: "Personal Finance Tracker",
    description: "An application for tracking personal finances, including expenses, income, investments, and budgeting tools with visual reports.",
    image: "https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d?auto=format&fit=crop&w=600",
    category: "Web Development",
  }
];
